# POS tahap 1: tangkapan layar dan perbandingan dengan mockup

Diambil dari aplikasi yang berjalan (API + Vite, data demo DEMO/BALI) pada 15 Okt 2026. Desktop 1366 px, ponsel 390 px.

| Layar | Desktop | Ponsel | Mockup |
|---|---|---|---|
| Folio: kunci untuk outlet, terkunci | `folio-kunci-outlet-terkunci-desktop.png` | | `13` (`mockup-13-referensi.png`) |
| Folio: kunci terbuka (batas, terpakai, sisa) | `folio-kunci-outlet-desktop.png` | `folio-kunci-outlet-ponsel.png` | `13` |
| Beban outlet masuk hari ini | `beban-outlet-masuk-desktop.png` | `beban-outlet-masuk-ponsel.png` | `13` (bagian bawah) |
| Master produk | `master-produk-desktop.png` | `master-produk-ponsel.png` | `15` (`mockup-15-referensi.png`) |
| Editor denah meja | `denah-editor-desktop.png` | `denah-editor-ponsel.png` | `10` (denah kasir: tahap 2) |
| Outlet | `outlet-desktop.png` | | |
| Stasiun dan printer, pemeriksaan pengaturan | `stasiun-printer-desktop.png` | | |
| Kategori, daftar harga, profil pajak dan servis | `kategori-harga-profil-desktop.png` | | |

## Sama dengan mockup

- 13: kartu "Beban dari outlet: terkunci" dengan batas, "berlaku sampai Check-out (tanggal)" berdampingan, daftar outlet berkotak centang, catatan pembukaan saat check-in, tombol "Buka untuk outlet"; daftar "Beban outlet masuk hari ini" dengan baris berwarna (masuk, ditolak) dan alasannya.
- 15: daftar produk per kategori dengan harga di kanan, kartu data produk, "Harga per outlet" (dijual, harga), "Varian" dan "Tambahan" bersisian, "Pajak & servis" (ikuti outlet / atur khusus), "Resep & biaya bahan" yang menunggu inventory, bilah Nonaktifkan / Simpan.

## Beda dari mockup (disengaja)

- Folio terbuka menampilkan batas, terpakai dan sisa (angka dari server); mockup hanya menggambar keadaan terkunci.
- "Beban outlet masuk hari ini" adalah halaman sendiri (`/outlet-charges`), bukan bagian dari halaman folio satu kamar, karena daftarnya untuk semua kamar. Kolom "baru" (titik biru) belum ada: pembaruan langsung menunggu tahap 3.
- Master produk: harga per outlet mengikuti daftar harga outlet (outlet yang memakai daftar yang sama tampil sekali dan yang kedua tidak bisa diubah). Mockup tidak membedakannya.
- Resep hanya catatan: tabel bahan menunggu modul inventory (tahap 4).
- Denah: editor ada di tahap 1; layar kasir denah (mockup 10) dibangun di tahap 2.
